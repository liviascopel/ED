// Created by Livia H. R. Scopel on 20/06/2024

#include "utils.h"

void bubbleSort(int vet[], int n)
{
    int aux;
    for (int i = 0; i < n; i++)
    {
        for (int j = i+1; j < n-1; j++)
        {
            if (vet[i] > vet[j])
            {
                aux = vet[i];
                vet[i] = vet[j];
                vet[j] = aux;
            }
        }
    }
}

void quickSort(int vet[], int n)
{
    if (n <= 1)
        return;
    else
    {
        int x = vet[0];
        int a = 1;
        int b = n-1;
        do {
            while (a < n && vet[a] <= x)
                a++;
            while (vet[b] > x)
                b--;
            if (a < b) {
                int temp = vet[a];
                vet[a] = vet[b];
                vet[b] = temp;
                a++;
                b--;
            }
        }
        while (a <= b);
        vet[0] = vet[b];
        vet[b] = x;

        quickSort(vet, b);
        quickSort(&vet[a], n-a);
    }
}

int linearSearch(int vet[], int n, int elem)
{
    for (int i = 0; i < n; i++)
    {
        if (vet[i] == elem)
        {
            return i;
        }
    }
    return -1;
}

int binarySearch(int vet[], int n, int elem)
{
    int inicio = 0;
    int fim = n-1;
    int meio;

    while (inicio <= fim)
    {
        meio = (inicio + fim) / 2;
        if (elem < vet[meio])
            fim = meio - 1;
        else if (elem > vet[meio])
            inicio = meio + 1;
        else
            return meio;
    }
    return -1;
}